#-*- coding:utf-8 -*-

from . import hr_payroll_payslips_by_employees
from . import hr_payroll_contribution_register_report
